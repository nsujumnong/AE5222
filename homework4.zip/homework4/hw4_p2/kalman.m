function [ output_args ] = kalman( input_args )
%KALMAN Summary of this function goes here
%   Detailed explanation goes here


end

